export const studies = [

    //First Study
    {
        thumbnails: [
            //First Series
            {
                imageSrc:
                    'https://raw.githubusercontent.com/crowds-cure/cancer/master/public/screenshots/Anti-PD-1_Lung.jpg',
                seriesDescription: 'Anti-PD-1_Lung',
                active: true,
                seriesNumber: '2',
                numImageFrames: 512,
                stackPercentComplete: 30,
                //List of objects
                ObjctVerionsPath: []

            },
            {
                imageSrc:
                    'https://raw.githubusercontent.com/crowds-cure/cancer/master/public/screenshots/Anti-PD-1_Lung.jpg',
                seriesDescription: 'Anti-PD-1_Lung',
                active: true,
                seriesNumber: '2',
                numImageFrames: 512,
                stackPercentComplete: 30,
                ObjctVerionsPath: []

            },
            {
                imageSrc:
                    'https://raw.githubusercontent.com/crowds-cure/cancer/master/public/screenshots/Anti-PD-1_Lung.jpg',
                seriesDescription: 'Anti-PD-1_Lung',
                active: true,
                seriesNumber: '2',
                numImageFrames: 512,
                stackPercentComplete: 30,
                ObjctVerionsPath: []

            },
        ],
    },

];

export function onThumbnailClick() {
    console.warn('onThumbnailClick');
}

export function onThumbnailDoubleClick() {
    console.warn('onThumbnailDoubleClick');
}
