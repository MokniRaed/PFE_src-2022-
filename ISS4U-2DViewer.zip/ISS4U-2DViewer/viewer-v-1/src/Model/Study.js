
export interface Series {
    seriesKy: number;
    select: boolean;
    seriesPrntky: number;
    seriesDesc: String;
    seriesBodypart: String;
    seriesDcmmdlty: String;
    seriesCtdlvol: String;
    seriesDlp: String;
    seriesUnxtmcrt: Date;
    seriesUnxtmupdt: Date;
    seriesRcrdsts: number;
}


export  interface StudyResponse {
    studyKy: number;
    select: boolean;
    studyPrntky: number;
    studyDesc: String;
    studyAccessnnmbr: String;
    studyCommnt: String;
    studyInsttnnm: String;
    studyRfrntphyscn: number;
    studyPrfrmngphyscn: number;
    studyAetitle: String;
    studyUnxtmcrt: Date;
    studyUnxtmupdt: Date;
    studyRcrdsts: number;
    series: Series [];
}



