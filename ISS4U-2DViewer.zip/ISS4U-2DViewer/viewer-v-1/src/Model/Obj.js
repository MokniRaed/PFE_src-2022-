export interface Series {
    objctKy:number;
    objctPrnttbl:number;
    objctPrntky:number;
    objctNm:string;
    objctTp:number;
    objctRcrdsts:number;
    objctUnxtmcrt:Date;
    objctUnxtmupdt:Date;
}
