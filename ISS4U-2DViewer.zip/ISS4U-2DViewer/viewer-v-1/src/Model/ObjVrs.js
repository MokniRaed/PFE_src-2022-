export interface Series {
    objctvrsnKy:number;
    objctvrsnPrntky:number;
    objctvrsnVrsnnmbr:number;
    objctvrsnPth:string;
    objctvrsnRcrdsts:number;
    objctvrsnUnxtmcrt:Date;
    objctvrsnUnxtmupdt:Date
}
