import App from "../App";
import CornerstoneViewport from "react-cornerstone-viewport";

function Container(){


  return (
    // <div id="Viewer-Container" className="Viewer-Container"
    //      style={{width: '100%', display: state.display2D === true ? 'flex' : 'none',}}>
    //
    //   {state.viewports.map(viewportIndex => (
    //
    //     <CornerstoneViewport
    //       style={{
    //         minWidth: (state.width) + '%',
    //         minHeight: (state.height) + 'px',
    //         flexWrap: 'wrap',
    //         display: 'inline-block',
    //         height: state.height + 'px',
    //         width: state.width + '%',
    //         borderColor: "#20a5d6"
    //       }}
    //       imageIdIndex={state.imageIdIndex}
    //       key={viewportIndex}
    //       tools={state.tools}
    //       imageIds={state.imageIds}
    //       activeTool={state.activeTool}
    //       isPlaying={state.isPlaying}
    //       frameRate={state.cineFrameRate}
    //       className={state.activeViewportIndex === viewportIndex ? 'active' : ''}
    //       setViewportActive={() => {
    //         this.setState({
    //           activeViewportIndex: viewportIndex,
    //         });
    //       }}
    //       isStackPrefetchEnabled={false}
    //
    //     />
    //   ))}
    // </div>
    <div/>
  );
}
export default Container;
