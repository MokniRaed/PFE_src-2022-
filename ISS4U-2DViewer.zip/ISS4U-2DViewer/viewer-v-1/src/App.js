import './App.css';
import {useEffect, useState} from "react";
import initCornerstone from "./config/cornerStoneCofig";

import Header from "./Components/header";
import Viewport2d from "./Components/viewport-2d";
import Toolbar from "./Components/toolbar";
import {useParams} from "react-router-dom";
import {getImgPathById, getStudyById} from "./utils/StudyService";
import type {StudyResponse} from "./Model/Study";


// const stack1 = [
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.8.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.7.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.9.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.10.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.12.dcm',
// ];
//
// const stack2 = [
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.9.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.10.dcm',
//     'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
// ];
const stack3 = [
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
];


// const serverStack = [('wadouri://vosimmo.000webhostapp.com/assets/img/0002.DCM')];


function App() {

    const height = 602;
    const width = 100;
    const {type,id, token,} = useParams();
    const dcmProtocal = 'dicomweb://'

    // const [isViewPort2DLoaded,setIsViewPort2DLoaded] = useState( false)

    //Get token from link and Set it in localStorage
    window.localStorage.setItem("jwt", token);

    const [state, setState] = useState(
        {

            activeViewportIndex: 0,
            viewports: [0],
            tools: [
                // Mouse
                {
                    name: 'Wwwc',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 1},
                },
                {
                    name: 'Zoom',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 2},
                },
                {
                    name: 'Pan',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 4},
                },
                //declaration
                {
                    name: 'Magnify',
                    mode: 'active',
                },
                {
                    name: 'Invert',
                    mode: 'active',
                },
                {
                    name: 'StackScroll',
                    mode: 'active',
                },
                {
                    name: 'Length',
                    mode: 'active',
                },
                {
                    name: 'Angle',
                    mode: 'active',
                },
                {
                    name: 'ArrowAnnotate',
                    mode: 'active',
                },

                {
                    name: 'DragProbe', //
                    mode: 'active',
                },
                {
                    name: 'EllipticalRoi',
                    mode: 'active',
                },
                {
                    name: 'Rotate',
                    mode: 'active',
                },
                {
                    name: 'WwwcRegion',
                    mode: 'active',
                },
                {
                    name: 'Eraser',
                    mode: 'active',
                },
                {
                    name: 'Bidirectional',
                    mode: 'active',
                },
                {
                    name: 'Invert',
                    mode: 'active',
                    type: 'command',
                    commandName: 'invertViewport',
                },


                {
                    name: "RectangleRoi",
                    // toolClass: RectangleRoi,
                    mode: "active",
                },
                // Scroll
                {name: 'StackScrollMouseWheel', mode: 'active'},
                // Touch
                {name: 'PanMultiTouch', mode: 'active'},
                {name: 'ZoomTouchPinch', mode: 'active'},
                {name: 'StackScrollMultiTouch', mode: 'active'},
            ],
            imageIds: [],
            // FORM
            activeTool: 'Pan',
            imageIdIndex: 0,
            displayCine: true,
            isPlaying: false,
            cineFrameRate: 10,
            height: height,
            width: width,
            display2D: true,
            display3D: false,
            isStackPrefetchEnabled: true,
        }
    )


    useEffect(() => {

        initCornerstone();
        // getStudyById(id).then(r => {
        //     const list = [];
        //
        //     console.log("this is the result", r)
        //
        //     // r.series.forEach(s => {
        //     //     console.log("our serie is ", s)
        //     //     list.push(s.seriesKy);
        //     // });
        //     // setSeries(list);
        //     // console.log("description", r.studyDesc);
        // }).catch(error => {
        //     console.log("Something wrong 🙅‍♂️:" + error);
        // });



    },[]);



// fetch dicom series from data base
//   const incrim = () => {
//     let serverStack = [];
//     for (let i = 1; i <20 ; i++) {
//        serverStack.push('wadouri://vosimmo.000webhostapp.com/assets/img/series/image-00000'+i+'.dcm');
//        console.log("this is the "+i+"server incrime : "+serverStack );
//     }
//
//     return serverStack;
//   }



    return (
        <div className="App">
            <Header/>
            <Toolbar state={state} setState={setState} id={id} type={type}/>
            <div className="r3d" id="r3d"
                 style={{display: state.display2D === false ? 'none' : 'inline-block', flexWrap: 'wrap'}}>
            </div>
            <Viewport2d state={state} id={id}  />
        </div>
    );
}
export default App;
