import {CineDialog, Icon, LayoutButton, QuickSwitch} from "react-viewerbase";
import {studies} from "../__docs__/exampleStudies";

import {useEffect, useState} from "react";
import html2canvas from "html2canvas";
import download from "downloadjs";
import {getImgPathById} from "../utils/StudyService";




const Toolbar = ({state,setState,id,type}) => {

  const height = 602;
  const width = 100;
  const dcmProtocal = 'dicomweb://'


  const [studies,setStudies] = useState([
        {
            thumbnails: [
                {
                    imageSrc: '',
                    seriesDescription: 'Anti-PD-1_Lung',
                    active: true,
                    seriesNumber: '2',
                    numImageFrames: null,
                    stackPercentComplete: null,
                    ObjctVerionsPath: []

                },
            ],
        },


    ])



  const [layout, setLayout] = useState(
    {
      selectedCell: {
        col: 0,
        row: 0,
      },
    }
  )

  // useEffect(() => {
  //   // getStudyById(id).then(r => {
  //   //     const list = [];
  //   //
  //   //     console.log("this is the result", r)
  //   //
  //   //     // r.series.forEach(s => {
  //   //     //     console.log("our serie is ", s)
  //   //     //     list.push(s.seriesKy);
  //   //     // });
  //   //     // setSeries(list);
  //   //     // console.log("description", r.studyDesc);
  //   // }).catch(error => {
  //   //     console.log("Something wrong 🙅‍♂️:" + error);
  //   // });
  //
  //   getImgPathById(id).then(result => {
  //     // ToDo
  //     // when r become a Series => tell binom to change in back the r to a list
  //     // let list =  [];
  //     // r.forEach( e => {
  //     //     list.push(dcmProtocal+e);
  //     // })
  //     // setImgIds(list);
  //
  //   });
  //
  //
  // }, [id]);


  useEffect(()=>{
    handleLayoutCell();
  },[layout])

  const handleSelectTool = (tool) => {
    setState(prevState => ({...prevState, activeTool: tool}));
  }

  const handleLayoutCell = () => {
    let table = [];
    let Row = layout.selectedCell.row + 1;
    let Col = layout.selectedCell.col + 1;
    let numViewports = Row * Col;
    let newRow;
    let newCol;


    for (let i = 0; i < numViewports; i++) {
      table.push(i);
    }

    for (let row = 0; row < layout.selectedCell.row + 1; row++) {
      newRow = row;
      for (let col = 0; col < layout.selectedCell.col + 1; col++) {
        newCol = col;
      }
    }

    setState(prevState => ({...prevState, width: width / Col}));
    setState(prevState => ({...prevState, height: height / Row}));
    setState(prevState => ({...prevState, viewports: table}));
  }

  const toggleDisplayCine = () => {
    setState(prevState => ({...prevState, displayCine: !state.displayCine}));

  }

  function handleCinePlay() {
    setState(prevState => ({...prevState, isPlaying: !state.isPlaying}));

  }

  const toggle3d2dViewer = () => {
    setState(prevState => ({...prevState, display2D: !state.display2D}));

  }

  async function downloadPng(id, filename) {
    const el = document.getElementById(id);
    const canvas = await html2canvas(el);
    const png = canvas && canvas.toDataURL("image/png");
      download(png, `${filename}.png`, "image/png");
  }


  return (
    <>
      <div className="ToolbarSection">
        <div className={`toolbar-button ${state.activeTool === "Pan" ? "active" : ""}`}
             onClick={() => handleSelectTool('Pan')}>
          <Icon name={'arrows'}/>

          <div className="toolbar-button-label">Pan</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Wwwc" ? "active" : ""}`}
             onClick={() => handleSelectTool('Wwwc')}>
          <Icon name={'level'}/>

          <div className="toolbar-button-label">Levels</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Zoom" ? "active" : ""}`}
             onClick={() => handleSelectTool('Zoom')}>
          <Icon name={'search-plus'}/>

          <div className="toolbar-button-label">Zoom</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Bidirectional" ? "active" : ""}`}
             onClick={() => handleSelectTool('Bidirectional')}>
          <Icon name={'measure-target'}/>

          <div className="toolbar-button-label">Bidirectional</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "StackScroll" ? "active" : ""}`}
             onClick={() => handleSelectTool('StackScroll')}>
          <Icon name={'bars'}/>

          <div className="toolbar-button-label">Stack Scroll</div>
        </div>
        {/*<div className={`toolbar-button`} onClick={() => handleSelectTool('clearAnnotations')}>*/}
        {/*  <Icon name={'reset'}/>*/}
        {/*  <div className="toolbar-button-label">clear</div>*/}
        {/*</div>*/}
        <div className={`toolbar-button ${state.activeTool === "Magnify" ? "active" : ""}`}
             onClick={() => handleSelectTool('Magnify')}>
          <Icon name={'dot-circle'}/>
          <div className="toolbar-button-label">Magnify</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Angle" ? "active" : ""}`}
             onClick={() => handleSelectTool('Angle')}>
          <Icon name={'measure-temp'}/>
          <div className="toolbar-button-label">Angle</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "ArrowAnnotate" ? "active" : ""}`}
             onClick={() => handleSelectTool('ArrowAnnotate')}>
          <Icon name={'measure-non-target'}/>
          <div className="toolbar-button-label">Annotation</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Length" ? "active" : ""}`}
             onClick={() => handleSelectTool('Length')}>
          <Icon name={'arrows-alt-v'}/>
          <div className="toolbar-button-label">Length</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "EllipticalRoi" ? "active" : ""}`}
             onClick={() => handleSelectTool('EllipticalRoi')}>
          <Icon name={'circle-o'}/>

          <div className="toolbar-button-label">Elliptical Roi</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Rotate" ? "active" : ""}`}
             onClick={() => handleSelectTool('Rotate')}>
          <Icon name={'rotate'}/>

          <div className="toolbar-button-label">Rotate</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Invert" ? "active" : ""}`}
             onClick={() => handleSelectTool('Invert')}>
          <Icon name={'adjust'}/>

          <div className="toolbar-button-label">Invert</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "Eraser" ? "active" : ""}`}
             onClick={() => handleSelectTool('Eraser')}>
          <Icon name={'trash'}/>
          <div className="toolbar-button-label">Eraser</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "WwwcRegion" ? "active" : ""}`}
             onClick={() => handleSelectTool('WwwcRegion')}>
          <Icon name={'stop'}/>
          <div className="toolbar-button-label">Window by Region</div>
        </div>
        <div className={`toolbar-button ${state.activeTool === "RectangleRoi" ? "active" : ""}`}
             onClick={() => handleSelectTool('RectangleRoi')}>
          <Icon name={'square-o'}/>
          <div className="toolbar-button-label">Rectangle</div>
        </div>
        <div className="toolbar-button"
             onClick={() => toggleDisplayCine()}>
          <Icon name={'youtube'}/>
          <div className="toolbar-button-label">CINE</div>
        </div>

        <div className="toolbar-button" style={{display: 'block'}} onClick={() => toggle3d2dViewer()}>
          <Icon name={'cube'}/>
          <div className="toolbar-button-label">3D</div>
        </div>
        <div className="toolbar-button" style={{display: 'block'}}
             onClick={() => downloadPng("Viewer-Container", "Study")}>
          <Icon name={'create-screen-capture'}/>
          <div className="toolbar-button-label">ScreenShot</div>
        </div>

        <LayoutButton
          onChange={cell => {
            setLayout({selectedCell: cell});
            console.log(cell)
          }}
          onClick={()=>handleLayoutCell()}
        />

      </div>

      <div style={{paddingTop: "15px", marginLeft: "15px"}}>
        <QuickSwitch
          studyListData={studies}
          // onSeriesSelected={selectedSeries => {
          //     const {studyListData} = state
          //     const selectedId = state.imageIds
          //     studyListData.forEach(study => {
          //         study.thumbnails.forEach(series => {
          //             series.active = series.active === selectedId
          //         })
          //     })
          // }}
        />
      </div>

      <div style={{
        zIndex: '999',
        position: 'absolute',
        display: (state.displayCine === false ? "block" : "none"),
        top: '120px',
        left: '900px'
      }}>
        <CineDialog
          cineStepFrameRate={state.cineFrameRate}
          onPlayPauseChanged={() => handleCinePlay()}/>
      </div>
    </>
  );
}
export default Toolbar;
