import CornerstoneViewport from "react-cornerstone-viewport";
import {useEffect, useState} from "react";
import initCornerstone from "../config/cornerStoneCofig";
import {getImgPathById} from "../utils/StudyService";


const Viewport2d = ({state, id, type}) => {

    const dcmProtocal = 'dicomweb://'

    const [imgIds, setImgIds] = useState([])

    useEffect(() => {
        // getStudyById(id).then(r => {
        //     const list = [];
        //
        //     console.log("this is the result", r)
        //
        //     // r.series.forEach(s => {
        //     //     console.log("our serie is ", s)
        //     //     list.push(s.seriesKy);
        //     // });
        //     // setSeries(list);
        //     // console.log("description", r.studyDesc);
        // }).catch(error => {
        //     console.log("Something wrong 🙅‍♂️:" + error);
        // });

        getImgPathById(id).then(result => {
            // ToDo
            // when r become a Series => tell binom to change in back the r to a list
            // let list =  [];
            // r.forEach( e => {
            //     list.push(dcmProtocal+e);
            // })
            // setImgIds(list);

            const imgPath = dcmProtocal + result;
            setImgIds([imgPath]);
            console.log("img is here: ", imgPath)
        });


    }, [id]);

    return (
        <div id="Viewer-Container" className="Viewer-Container"
             style={{width: '100%', display: state.display2D === true ? 'flex' : 'none',}}>

            {state.viewports.map(viewportIndex => {
                    return imgIds.length > 0 ? <CornerstoneViewport
                        style={{
                            minWidth: (state.width) + '%',
                            minHeight: (state.height) + 'px',
                            flexWrap: 'wrap',
                            display: 'inline-block',
                            height: state.height + 'px',
                            width: state.width + '%',
                            borderColor: "#20a5d6"
                        }}
                        imageIdIndex={state.imageIdIndex}
                        key={viewportIndex}
                        tools={state.tools}
                        imageIds={imgIds}
                        activeTool={state.activeTool}
                        isPlaying={state.isPlaying}
                        frameRate={state.cineFrameRate}
                        className={state.activeViewportIndex === viewportIndex ? 'active' : ''}
                        setViewportActive={() => {
                            this.setState({
                                activeViewportIndex: viewportIndex,
                            });
                        }}
                        isStackPrefetchEnabled={true}

                    /> : null
                }
            )}
        </div>
    );
}
export default Viewport2d;
