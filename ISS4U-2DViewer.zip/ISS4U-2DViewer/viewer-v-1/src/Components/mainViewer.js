import './App.css';
import {useEffect, useState} from "react";
import initCornerstone from "./config/cornerStoneCofig";

import {request} from "./utils/axios-utils";
import Header from "./Components/header";
import Viewport2d from "./Components/viewport-2d";
import Toolbar from "./Components/toolbar";


const stack1 = [
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.8.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.7.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.9.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.10.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.12.dcm',
];

const stack2 = [
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.9.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.10.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
];
const stack3 = [
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.11.dcm',
    'dicomweb://s3.amazonaws.com/lury/PTCTStudy/1.3.6.1.4.1.25403.52237031786.3872.20100510032220.12.dcm',
];

const getSeries = () => {
    return request({url:'/36444294'})
}

// const serverStack = [('wadouri://vosimmo.000webhostapp.com/assets/img/0002.DCM')];

// const issServer = [('wadouri://iss-4u.com/dicom/dataset01/ADNI4-DICOM-nano-10514/002_S_0413/Axial_3TE_T2_STAR/2019-08-27_09_39_37.0/S868724/ADNI_002_S_0413_MR_Axial_3TE_T2_STAR__br_raw_20190828115108623_47_S868724_I1221049.dcm')];

// brain picture
// const serverStack = [('wadouri://cdn.rawgit.com/FNNDSC/data/master/dicom/adi_brain/36444280')];


function App() {

    const height = 602;
    const width = 100;
    // const _cornerstoneWADOImage = cornerstoneWADOImageLoader.wadors.metaData,
    //     getNumberValue = _cornerstoneWADOImage.getNumberValue,
    //     getValue = _cornerstoneWADOImage.getValue;
    //
// fetch dicom series from data base
//   const incrim = () => {
//     let serverStack = [];
//     for (let i = 1; i <20 ; i++) {
//        serverStack.push('wadouri://vosimmo.000webhostapp.com/assets/img/series/image-00000'+i+'.dcm');
//        console.log("this is the "+i+"server incrime : "+serverStack );
//     }
//
//     return serverStack;
//   }


    useEffect(() => {
        initCornerstone()
    }, [])



    const [state, setState] = useState(
        {
            activeViewportIndex: 0,
            viewports: [0],
            tools: [
                // Mouse
                {
                    name: 'Wwwc',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 1},
                },
                {
                    name: 'Zoom',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 2},
                },
                {
                    name: 'Pan',
                    mode: 'active',
                    modeOptions: {mouseButtonMask: 4},
                },
                //declaration
                {
                    name: 'Magnify',
                    mode: 'active',
                },
                {
                    name: 'Invert',
                    mode: 'active',
                },
                {
                    name: 'StackScroll',
                    mode: 'active',
                },
                {
                    name: 'Length',
                    mode: 'active',
                },
                {
                    name: 'Angle',
                    mode: 'active',
                },
                {
                    name: 'ArrowAnnotate',
                    mode: 'active',
                },

                {
                    name: 'DragProbe', //
                    mode: 'active',
                },
                {
                    name: 'EllipticalRoi',
                    mode: 'active',
                },
                {
                    name: 'Rotate',
                    mode: 'active',
                },
                {
                    name: 'WwwcRegion',
                    mode: 'active',
                },
                {
                    name: 'Eraser',
                    mode: 'active',
                },
                {
                    name: 'Bidirectional',
                    mode: 'active',
                },
                {
                    name: 'Invert',
                    mode: 'active',
                    type: 'command',
                    commandName: 'invertViewport',
                },


                {
                    name: "RectangleRoi",
                    // toolClass: RectangleRoi,
                    mode: "active",
                },
                // Scroll
                {name: 'StackScrollMouseWheel', mode: 'active'},
                // Touch
                {name: 'PanMultiTouch', mode: 'active'},
                {name: 'ZoomTouchPinch', mode: 'active'},
                {name: 'StackScrollMultiTouch', mode: 'active'},
            ],
            imageIds: stack2,
            // FORM
            activeTool: 'Pan',
            imageIdIndex: 0,
            displayCine: true,
            isPlaying: false,
            cineFrameRate: 10,
            height: height,
            width: width,
            display2D: true,
            display3D: false,
            isStackPrefetchEnabled: true,
        }
    )


    return (
        <div className="App">
            <Header/>
            <Toolbar state={state} setState={setState}/>

            <div className="r3d" id="r3d"
                 style={{display: state.display2D === false ? 'none' : 'inline-block', flexWrap: 'wrap'}}>
            </div>

            <Viewport2d state={state} setState={setState}/>


        </div>
    );
}

export default App;
