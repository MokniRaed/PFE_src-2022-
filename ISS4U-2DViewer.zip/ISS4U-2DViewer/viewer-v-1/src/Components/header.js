const Header = () => {
  return (
    <div className="App-header">
      <div className="App-logo">
      </div>
      <h1 style={{display: "inline-block", paddingLeft: "10px", transform: "translateY(-10%)",}}>Intelligent Software
        Solution For You</h1>
    </div>
  );
}
export default Header;
